import re
from typing import List, Dict, Tuple
from rapidfuzz import fuzz, process
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
import json
import os

def _normalize_text(t: str) -> str:
    t = t or ""
    t = t.lower()
    t = re.sub(r"\s+", " ", t)
    return t.strip()

def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Simple PDF text extraction using PyPDF2."""
    from PyPDF2 import PdfReader
    import io
    reader = PdfReader(io.BytesIO(file_bytes))
    texts = []
    for page in reader.pages:
        try:
            texts.append(page.extract_text() or "")
        except Exception:
            continue
    return "\n".join(texts)

def extract_text_from_docx(file_bytes: bytes) -> str:
    """Extract text from DOCX using docx2txt."""
    import io, docx2txt, tempfile, os
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = os.path.join(tmpdir, "resume.docx")
        with open(tmp_path, "wb") as f:
            f.write(file_bytes)
        text = docx2txt.process(tmp_path) or ""
    return text

def detect_sections(text: str) -> Dict[str, str]:
    """Crude section splitter based on common resume headings."""
    sections = ["summary","objective","experience","work experience","projects","education","skills","certifications","achievements","publications","contact"]
    txt = text
    found = {}
    lower = txt.lower()
    # Find indices of headings
    indices = []
    for s in sections:
        m = re.finditer(rf"\n?\s*{re.escape(s)}\s*[:\n]", lower)
        for mm in m:
            indices.append((mm.start(), s))
    indices.sort()
    # Segment text
    for i, (idx, name) in enumerate(indices):
        start = idx
        end = indices[i+1][0] if i+1 < len(indices) else len(txt)
        found[name] = txt[start:end].strip()
    # Fallback minimal segments
    if not found:
        found["full_text"] = txt
    return found

def load_taxonomy(path: str) -> Dict[str, List[str]]:
    with open(path, "r") as f:
        return json.load(f)

def extract_skills(text: str, taxonomy: Dict[str, List[str]], threshold: int = 88) -> Dict[str, List[str]]:
    """Fuzzy match skills from taxonomy."""
    txt = _normalize_text(text)
    results = {cat: [] for cat in taxonomy}
    for cat, skills in taxonomy.items():
        for sk in skills:
            # allow small fuzziness
            ratio = fuzz.partial_ratio(sk, txt)
            if ratio >= threshold:
                results[cat].append(sk)
    # remove empties
    return {k: sorted(set(v)) for k, v in results.items() if v}

def extract_keywords_tfidf(text: str, top_k: int = 20) -> List[str]:
    """Simple TF-IDF keyword extraction from a single document by splitting into sentences."""
    # Split into pseudo-documents (sentences)
    sents = [s.strip() for s in re.split(r"[\.!?\n]", text) if s.strip()]
    if not sents:
        return []
    vec = TfidfVectorizer(stop_words="english", ngram_range=(1,2), min_df=1)
    X = vec.fit_transform(sents)
    scores = np.asarray(X.mean(axis=0)).ravel()
    idx = scores.argsort()[::-1]
    feats = np.array(vec.get_feature_names_out())
    top = feats[idx][:top_k]
    return top.tolist()

def compute_ats_score(resume_text: str, job_text: str, extracted_skills: Dict[str, List[str]]) -> Dict[str, float]:
    """Compute a simple ATS score combining keyword overlap, skill coverage, and formatting basics."""
    resume = _normalize_text(resume_text)
    job = _normalize_text(job_text)
    # Keyword overlap via TF-IDF
    if job:
        kw_resume = set(extract_keywords_tfidf(resume, 30))
        kw_job = set(extract_keywords_tfidf(job, 30))
        if kw_job:
            kw_overlap = len(kw_resume & kw_job) / max(1, len(kw_job))
        else:
            kw_overlap = 0.0
    else:
        kw_overlap = 0.0

    # Skill coverage
    flat_skills = set([s for arr in extracted_skills.values() for s in arr])
    # Derive skills from job text using taxonomy too
    # Here we reuse taxonomy within this function by detecting common tech tokens in job_text
    # Simple heuristic: intersect with a known tech lexicon
    tech_lexicon = set([
        "python","java","javascript","typescript","c","c++","c#","go","rust","react","node.js","express",
        "spring","django","flask","fastapi","aws","azure","gcp","docker","kubernetes","sql","mysql","postgresql",
        "mongodb","redis","graphql","rest api","pandas","numpy","tensorflow","pytorch","scikit-learn","opencv",
        "nlp","llm","transformers","kafka","rabbitmq","git","linux","microservices","webrtc","websockets"
    ])
    job_skill_hits = set([t for t in tech_lexicon if t in job])
    skill_coverage = (len(flat_skills & job_skill_hits) / max(1, len(job_skill_hits))) if job_skill_hits else (len(flat_skills) > 0) * 0.5

    # Formatting basics
    basics = 0.0
    # presence of email/phone/linkedin
    if re.search(r"[\w\.-]+@[\w\.-]+", resume): basics += 0.34
    if re.search(r"\+?\d[\d\s\-()]{6,}", resume): basics += 0.33
    if "linkedin.com" in resume or "github.com" in resume: basics += 0.33

    score = 100 * (0.5*kw_overlap + 0.3*skill_coverage + 0.2*basics)
    return {
        "overall": round(score, 2),
        "keyword_overlap": round(100*kw_overlap, 2),
        "skill_coverage": round(100*skill_coverage, 2),
        "basics": round(100*basics, 2)
    }

def suggest_improvements(job_text: str, skills_found: Dict[str, List[str]], taxonomy: Dict[str, List[str]]) -> Dict[str, List[str]]:
    """Suggest missing skills by comparing job requirements with extracted skills."""
    job = _normalize_text(job_text)
    # Build a set of possible skills (flatten taxonomy)
    all_skills = set([s for arr in taxonomy.values() for s in arr])
    # Skills hinted by job description (simple containment)
    job_skills = set([s for s in all_skills if s in job])
    resume_skills = set([s for arr in skills_found.values() for s in arr])
    missing = sorted(job_skills - resume_skills)
    # Generic tips
    tips = [
        "Add quantifiable achievements (e.g., 'reduced latency by 35%').",
        "Use active verbs (built, optimized, deployed, automated).",
        "Mirror keywords from the job description naturally.",
        "Keep resume to 1 page (fresher) or 2 pages (experienced).",
        "Ensure consistent formatting and section headers.",
        "Include links: GitHub, portfolio, LinkedIn."
    ]
    return {"missing_skills": missing, "general_tips": tips}

def generate_html_report(name: str, email: str, ats: dict, skills_found: dict, suggestions: dict) -> str:
    import html
    def badge(txt):
        return f'<span style="display:inline-block;padding:6px 10px;margin:4px;border-radius:14px;background:#eef;border:1px solid #ccd">{html.escape(txt)}</span>'
    # Build skill badges
    skill_html = ""
    for cat, items in skills_found.items():
        if not items: continue
        skill_html += f"<h4>{html.escape(cat)}</h4>\n<p>" + " ".join(badge(i) for i in sorted(set(items))) + "</p>"
    miss_html = " ".join(badge(i) for i in suggestions.get("missing_skills", [])) or "<i>No critical gaps detected.</i>"
    tips_html = "<ul>" + "".join(f"<li>{html.escape(t)}</li>" for t in suggestions.get("general_tips", [])) + "</ul>"
    html_doc = f"""
    <html>
    <head>
        <meta charset="utf-8" />
        <title>AI Resume Analyzer Report</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; margin: 24px; }}
            .card {{ border:1px solid #e5e7eb; border-radius:16px; padding:18px; margin-bottom:18px; }}
            .grid {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap:16px; }}
            h1,h2,h3,h4 {{ margin: 6px 0 8px; }}
            .stat {{ font-size: 28px; font-weight: 700; }}
            .muted {{ color:#666; }}
        </style>
    </head>
    <body>
        <h1>AI Resume Analyzer Report</h1>
        <p class="muted">Candidate: <b>{html.escape(name or 'Unknown')}</b> • {html.escape(email or '')}</p>
        <div class="grid">
            <div class="card"><div class="muted">Overall ATS Score</div><div class="stat">{ats.get('overall',0)}%</div></div>
            <div class="card"><div class="muted">Keyword Overlap</div><div class="stat">{ats.get('keyword_overlap',0)}%</div></div>
            <div class="card"><div class="muted">Skill Coverage</div><div class="stat">{ats.get('skill_coverage',0)}%</div></div>
            <div class="card"><div class="muted">Formatting Basics</div><div class="stat">{ats.get('basics',0)}%</div></div>
        </div>
        <div class="card">
            <h2>Detected Skills</h2>
            {skill_html or '<i>No skills detected.</i>'}
        </div>
        <div class="card">
            <h2>Suggestions</h2>
            <h4>Missing Skills (based on Job Description)</h4>
            <p>{miss_html}</p>
            <h4>General Tips</h4>
            {tips_html}
        </div>
    </body>
    </html>
    """
    return html_doc