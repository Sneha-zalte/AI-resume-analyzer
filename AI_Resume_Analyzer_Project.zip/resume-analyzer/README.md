# 🧠 AI Resume Analyzer (Streamlit)

Analyze resumes for ATS readiness: extract skills, compute a simple ATS score, find missing keywords vs a job description, and download a clean report.

## ✨ Features
- Upload **PDF/DOCX** resumes
- Detect sections and show a **clean overview**
- **Skill extraction** with fuzzy matching using a curated taxonomy
- **TF-IDF keyword extraction**
- **ATS-style scoring** (keyword overlap + skill coverage + formatting basics)
- **Suggestions**: missing skills & general improvement tips
- **HTML Report** download

## 🧰 Tech Stack
- Streamlit, PyPDF2, docx2txt, rapidfuzz, scikit-learn, pandas, numpy

## 🚀 Run Locally
```bash
python -m venv .venv
source .venv/bin/activate   # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## 🗂️ Project Structure
```
resume-analyzer/
├── app.py
├── utils_nlp.py
├── skills_taxonomy.json
├── assets/
│   └── style.css
└── requirements.txt
```

## 📝 Notes
- This is a lightweight prototype (no heavy models). For production, integrate spaCy/Transformers and better PDF parsing.
- If your PDF is scanned (image), OCR is required (e.g., `pytesseract` + `pdf2image`).

## 📄 License
MIT