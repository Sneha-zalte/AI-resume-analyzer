import streamlit as st
import base64, re, json
from utils_nlp import (
    extract_text_from_pdf, extract_text_from_docx, detect_sections,
    load_taxonomy, extract_skills, extract_keywords_tfidf,
    compute_ats_score, suggest_improvements, generate_html_report
)

st.set_page_config(page_title="AI Resume Analyzer", page_icon="🧠", layout="wide")

# Custom CSS
with open("assets/style.css", "r") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("🧠 AI Resume Analyzer")
st.caption("Upload your resume, paste a job description, and get an ATS-style breakdown with improvement tips.")

with st.sidebar:
    st.header("⚙️ Settings")
    st.write("This tool runs fully local in your session.")
    th = st.slider("Skill Match Threshold", 80, 95, 88, 1)
    topk = st.slider("Top Keywords (TF-IDF)", 10, 40, 20, 1)
    st.markdown("---")
    st.write("Built with ❤️ for #15Days15Projects")

col1, col2 = st.columns(2)
with col1:
    uploaded = st.file_uploader("📄 Upload Resume (PDF/DOCX)", type=["pdf","docx"], accept_multiple_files=False)
    name = st.text_input("Name (optional)")
    email = st.text_input("Email (optional)")
with col2:
    job_desc = st.text_area("🧾 Paste Job Description (optional for ATS scoring)", height=220, placeholder="Paste the target job description here...")

taxonomy = load_taxonomy("skills_taxonomy.json")

if uploaded:
    # Read resume text
    file_bytes = uploaded.read()
    if uploaded.name.lower().endswith(".pdf"):
        resume_text = extract_text_from_pdf(file_bytes)
    else:
        resume_text = extract_text_from_docx(file_bytes)

    if not resume_text.strip():
        st.error("Couldn't extract text from the file. Make sure it's selectable text (not a scanned image).")
        st.stop()

    # Dynamic UI: Tabs for Experience, Projects, Skills, Report
    t1, t2, t3, t4 = st.tabs(["🔍 Overview", "🛠️ Skills & Keywords", "📊 ATS Score", "📥 Report"])

    with t1:
        st.subheader("Resume Overview")
        secs = detect_sections(resume_text)
        st.write("Detected sections from your resume:")
        for k, v in secs.items():
            with st.expander(k.title(), expanded=False):
                st.write(v[:1200] + ("..." if len(v) > 1200 else ""))

        st.markdown("**Raw Extracted Text (first 1000 chars)**")
        st.code(resume_text[:1000] + ("..." if len(resume_text) > 1000 else ""), language="markdown")

    with t2:
        st.subheader("Skills & Keywords")
        found_skills = extract_skills(resume_text, taxonomy, threshold=th)
        if found_skills:
            st.markdown("**Detected Skills**")
            for cat, items in found_skills.items():
                st.markdown(f"**{cat}**")
                st.markdown("".join([f"<span class='badge'>{i}</span>" for i in sorted(set(items))]), unsafe_allow_html=True)
        else:
            st.info("No skills detected at the current threshold. Try lowering the threshold in the sidebar.")

        st.markdown("---")
        st.markdown("**Top Keywords (TF-IDF)**")
        kws = extract_keywords_tfidf(resume_text, top_k=topk)
        if kws:
            st.markdown("".join([f"<span class='badge'>{k}</span>" for k in kws]), unsafe_allow_html=True)
        else:
            st.write("Not enough text for keyword extraction.")

    with t3:
        st.subheader("ATS Score & Insights")
        found_skills = extract_skills(resume_text, taxonomy, threshold=th)
        ats = compute_ats_score(resume_text, job_desc or "", found_skills)

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Overall ATS", f"{ats['overall']}%")
        c2.metric("Keyword Overlap", f"{ats['keyword_overlap']}%")
        c3.metric("Skill Coverage", f"{ats['skill_coverage']}%")
        c4.metric("Basics", f"{ats['basics']}%")

        st.markdown("---")
        st.markdown("**Suggestions**")
        sugg = suggest_improvements(job_desc or "", found_skills, taxonomy)
        with st.expander("Missing Skills vs Job Description"):
            if sugg["missing_skills"]:
                st.markdown("".join([f"<span class='badge'>{s}</span>" for s in sugg["missing_skills"]]), unsafe_allow_html=True)
            else:
                st.write("No critical gaps detected at this time.")
        with st.expander("General Tips"):
            for tip in sugg["general_tips"]:
                st.write(f"- {tip}")

    with t4:
        st.subheader("Download Report")
        found_skills = extract_skills(resume_text, taxonomy, threshold=th)
        ats = compute_ats_score(resume_text, job_desc or "", found_skills)
        sugg = suggest_improvements(job_desc or "", found_skills, taxonomy)
        html_doc = generate_html_report(name, email, ats, found_skills, sugg)
        b64 = base64.b64encode(html_doc.encode()).decode()
        st.download_button("⬇️ Download HTML Report", data=html_doc, file_name="resume_report.html", mime="text/html")

        st.caption("Tip: Open the HTML report in your browser and print to PDF if you need a PDF version.")

else:
    st.info("Upload a resume to start the analysis.")